package com.cg.greatOutdoors.dao;

import java.util.List;

import com.cg.greatOutdoors.entity.Address;

import com.cg.greatOutdoors.entity.User;
import com.cg.greatOutdoors.exception.UserException;

public interface AddressDAOInterface {
	

	
	public int insertAddress(Address address, int userId); 
	
	public List<Address> retreive();
	public Address findById(int addressId);
	
	public void delete(int addressId);
	public void update(Address address,int addressId);

}
