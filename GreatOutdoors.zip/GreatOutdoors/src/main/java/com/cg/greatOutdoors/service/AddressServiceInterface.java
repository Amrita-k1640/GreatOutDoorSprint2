package com.cg.greatOutdoors.service;

import java.util.List;

import com.cg.greatOutdoors.entity.Address;
import com.cg.greatOutdoors.entity.User;
import com.cg.greatOutdoors.exception.AddressServiceException;
import com.cg.greatOutdoors.exception.UserException;

public interface AddressServiceInterface {

	public int addAddress(Address address, int userId);

	public List<Address> retreive();

	public void delete(int addressId);

	public Address fingById(int addressId);

	public void update(Address address, int addressId);

}
