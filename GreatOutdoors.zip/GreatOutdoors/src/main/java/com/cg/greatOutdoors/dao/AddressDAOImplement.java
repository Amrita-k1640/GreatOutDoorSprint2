package com.cg.greatOutdoors.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.stereotype.Repository;
import com.cg.greatOutdoors.entity.Address;
import com.cg.greatOutdoors.entity.User;

@Repository

public class AddressDAOImplement implements AddressDAOInterface {

	@PersistenceContext
	EntityManager em;

	@Override
	public int insertAddress(Address address, int userId) {
		User user = em.find(User.class, userId);
		user.addAddress(address);
		return address.getAddressId();

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Address> retreive() {
		Query query = em.createQuery("from Address s");
		return query.getResultList();
	}

	@Override
	public void delete(int addressId) {
		Address address = em.find(Address.class, addressId);
		em.remove(address);
	}

	@Override
	public Address findById(int addressId) {
		return em.find(Address.class, addressId);
	}

	@Override
	public void update(Address address, int addressId) {

		Address updateAddress = em.find(Address.class, addressId);
		updateAddress.setBuildingNo(address.getBuildingNo());
		updateAddress.setCity(address.getCity());
		updateAddress.setField(address.getField());
		updateAddress.setState(address.getState());
		updateAddress.setZip(address.getZip());
		em.merge(updateAddress);

	}

}
