package com.cg.greatOutdoors.exception;

public class AddressServiceException extends RuntimeException{
	
	private static final long serialVersionUID= 1L;
	
	public AddressServiceException(String msg) {
		super(msg);
	}

}
