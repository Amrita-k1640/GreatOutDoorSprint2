package com.cg.greatOutdoors.service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.greatOutdoors.dao.AddressDAOImplement;
import com.cg.greatOutdoors.entity.Address;
import com.cg.greatOutdoors.entity.User;

@Transactional
@Service
public class AddressServiceImplementation implements AddressServiceInterface {

	
	@PersistenceContext
    private EntityManager em;
	
	@Autowired
	AddressDAOImplement pDao;

	@Override
	public int addAddress(Address address, int userId) {

		return pDao.insertAddress(address, userId);
	}

	@Override
	public List<Address> retreive() {

		return pDao.retreive();
	}

	@Override
	public void delete(int addressId) {
		pDao.delete(addressId);

	}
	
//	@Override
//	public void delete(int userId, int addressId) {
//		String addQuery="SELECT address FROM Address address WHERE  address.user.userId=:userId  AND address.addressId=:addressId";
//		TypedQuery<Address> query=em.createQuery(addQuery,Address.class);
//		query.setParameter("userId", userId);
//		query.setParameter("addressId", addressId);
//		Address address= query.getSingleResult();	
//		System.out.println(address);
//		em.remove(address);
//
//	}
//	
		

	@Override
	public void update(Address address, int id) {
		pDao.update(address, id);

	}

	@Override
	public Address fingById(int id) {
		return pDao.findById(id);
	}

}
