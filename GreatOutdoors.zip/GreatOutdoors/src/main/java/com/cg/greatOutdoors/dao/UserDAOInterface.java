package com.cg.greatOutdoors.dao;

import java.util.List;

import com.cg.greatOutdoors.entity.User;


public interface UserDAOInterface {
	
	public void create(User user);
	
	public User signUp(User user);
	
	Boolean delete(int id);

	boolean findId(int id);

	User findById(int id);

	boolean findUserByEmail(String email);

	User getUserByEmail(String email);

	public List<User> retrieveData();

	boolean updateLoginStatus(User user, int id);


	boolean updatePassword(User user, int id);


	boolean updateLogoutStatus(User user, String email);
}
