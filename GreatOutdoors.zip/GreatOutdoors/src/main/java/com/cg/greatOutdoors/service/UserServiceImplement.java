package com.cg.greatOutdoors.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.greatOutdoors.dao.UserDAOInterface;
import com.cg.greatOutdoors.entity.User;
import com.cg.greatOutdoors.entity.User.type;
import com.cg.greatOutdoors.exception.UserException;


@Service("userService")
public class UserServiceImplement implements UserServiceInterface {
	
	@Autowired
	private UserDAOInterface uDao;
	
	
	@Override
	public void create(User user) throws UserException {
		
		try {
			uDao.create(user);
		}
		catch(Exception exception)
		{
			throw new UserException("Unable to create user");
		}
		
	}
	
	boolean checkEmail(String email) throws UserException {
		 if(uDao.findUserByEmail(email)==true)
			 throw new UserException("User already exists, please login with your email");
		else return true;
	}
	@Override
    public User loginUser(String email, String password) throws UserException{   
    	if(uDao.findUserByEmail(email)==false)
    		throw new UserException("User does not exist, Please enter a valid email");
    	User user=uDao.getUserByEmail(email);
        if(user.getUserType()==type.admin)
        	throw new UserException("User login only");
    	if(user.getPassword().equals(password)==false)
    		throw new UserException("Email and password does not match");
    	if (uDao.updateLogoutStatus(user, email)!=true)
			throw new UserException("User already LoggedIn");
		return user;
    }
	@Override
    public User loginAdmin(String email, String password) throws UserException{   
    	if(uDao.findUserByEmail(email)==false)
    		throw new UserException("User does not exist, Please enter a valid email");
    	User user=uDao.getUserByEmail(email);
        if(user.getUserType()==type.user)
        	throw new UserException("Admin login only");
    	if(user.getPassword().equals(password)==false)
    		throw new UserException("Email and password does not match");
    	if (uDao.updateLogoutStatus(user, email)!=true)
			throw new UserException("Admin already LoggedIn");
    	return user;		
    }
	@Override
	public List<User> getAllUsers() {
		return uDao.retrieveData();
	}
	@Override
	public Boolean delete(int id) throws UserException {
		if(uDao.findId(id)==false)
    		throw new UserException("User does not exist");
		return uDao.delete(id);
	}
	@Override
	public User findById(int id) throws UserException {
		if(uDao.findId(id)==false)
    		throw new UserException("User does not exist");
		return uDao.findById(id);
	}
	@Override
	public boolean existsById(int id) throws UserException {
		if(uDao.findId(id)==false)
    		throw new UserException("User does not exist");
		return uDao.findId(id);
	}
	@Override
	public User findByEmail(String email) throws UserException {
		if(uDao.findUserByEmail(email)==false)
    		throw new UserException("User does not exist");
		return uDao.getUserByEmail(email);
	}
	@Override
	public boolean existsByEmail(String email) throws UserException {
		if(uDao.findUserByEmail(email)==false)
    		throw new UserException("User does not exist");
		return uDao.findUserByEmail(email);
	}
	
	@Override
	public String updatePassword(User user, int id) throws UserException {
		if (uDao.updatePassword(user, id)==true)
			return "Password Updated";
		else 
			throw new UserException("Error updating Password");
	}
	
	@Override
	public String logout(User user,int id) throws UserException{
		if (uDao.updateLoginStatus(user, id)!=true)
			throw new UserException("User already LoggedOut");
		else
			return "LoggedOut";
 	}

}
