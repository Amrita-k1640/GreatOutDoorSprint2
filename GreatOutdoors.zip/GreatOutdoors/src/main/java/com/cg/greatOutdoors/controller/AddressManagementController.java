package com.cg.greatOutdoors.controller;


import com.cg.greatOutdoors.entity.Address;
import com.cg.greatOutdoors.entity.User;
import com.cg.greatOutdoors.exception.AddressNotFoundException;

import com.cg.greatOutdoors.exception.IdNotFoundException;
import com.cg.greatOutdoors.exception.UserException;
import com.cg.greatOutdoors.service.AddressServiceImplementation;
import com.cg.greatOutdoors.service.UserServiceImplement;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/api")
public class AddressManagementController {
	
	@Autowired
	AddressServiceImplementation pService;
	
	@Autowired
	UserServiceImplement uService;
	
	
	 @RequestMapping("/home")
	    String home() {
	        return "Welcome to the Address Management System!!";
	    }
		
	 
	@PostMapping(value="/home/register",consumes="application/json")
	public String addUser(@RequestBody User user) throws UserException
	{
		Address address=new Address("123","Jalandhar","PB","LPU","144411");
		user.addAddress(address);
		uService.create(user);
		return "User registered Successfully";
		
	}
	
	@PostMapping(value="/home/addAddress/{userId}",consumes="application/json")
	public String addAddress(@RequestBody Address address , @PathVariable int userId) throws UserException
	{
		pService.addAddress(address,userId);		
		return "Address Added Successfully";
	}
	
	
	
	@GetMapping(value = "/home/showById/{id}")
	public Address findAddress(@PathVariable int id) throws AddressNotFoundException{
		if(id!=0) {
			return pService.fingById(id);
		}
		else
		{
			throw new IdNotFoundException("Id not found");
		}
		
	}


	@GetMapping(value="/home/showAll")
	public List<Address> fetchAddress() throws AddressNotFoundException
	{
		List<Address> address = pService.retreive();
		if(address!=null)
		{
			return  pService.retreive();
		}
		else
		{
			throw new AddressNotFoundException("Address not found");
		}
		
	}
	
	
	@DeleteMapping(value="/home/address/delete/{id}")
	public String deleteAddress(@PathVariable int id) throws AddressNotFoundException
	{
		Address address1 =  pService.fingById(id);
		if(address1!=null)
		{
			pService.delete(id);
			return "Address Deleted Successfully!!";
		}
		else
		{
			throw new AddressNotFoundException("Id does Not exist or Deleted!!");
		}	
	   
	}
	
	
	@PutMapping(value="/home/address/update/{id}",consumes= {"application/json"})
	public String updateAddress(@PathVariable int id,@RequestBody Address address) throws AccountNotFoundException
	{
		if(id!=0)
		{
			pService.update(address, id);
			return "Address Updated Successfully!!";
		}
		
		else
		{
			throw new AccountNotFoundException("AddressId is required for update ");
		}

	}
}
 