export class Userlogin {
    password: string;
    email: string;
}
