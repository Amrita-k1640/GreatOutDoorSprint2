export class User {
    userId: number;
    email: string;
    firstname: string;
    lastname: string;
    password: string;
    confirmPassword: string;
    phoneNumber: string;
}
