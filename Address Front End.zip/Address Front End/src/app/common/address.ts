export class Address {

    addressId:number;
    buildingNo: string;
    city:string;
    state:string;
    field:string;
    zip:string;


}



