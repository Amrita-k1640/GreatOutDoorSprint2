import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeComponent } from './component/home/home.component';
import { AdminComponent } from './component/admin/admin.component';
import { AdmimcontrolComponent } from './component/admincontrol/admincontrol.component';
import { EqualValidator } from './service/equal-validator.directive';
import { PagenotfoundComponent } from './component/pagenotfound/pagenotfound.component';
import { CreateAddressComponent } from './component/create-address/create-address.component';
import { ConfirmationPopoverModule } from 'angular-confirmation-popover';
import { AddressService} from './service/address.service';


import { AddressListComponent } from './component/address-list/address-list.component';

import { Routes, RouterModule } from "@angular/router";



import { AddressDetailsComponent } from './component/address-details/address-details.component';


import { UpdateAddressComponent } from './component/update-address/update-address.component';

//import { AdmincontrolComponent } from './component/admincontrol/admincontrol.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    HomeComponent,
    AdminComponent,
    AdmimcontrolComponent,
    EqualValidator,
    PagenotfoundComponent,
    CreateAddressComponent,
    AddressDetailsComponent,
    AddressListComponent,
    UpdateAddressComponent
    
    //AdmincontrolComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    ConfirmationPopoverModule.forRoot({
      confirmButtonType: 'danger'
    }),
  ],
  providers: [
    AddressService,
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }