import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from 'src/app/common/user';
import { Userlogin } from 'src/app/common/userlogin';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private users: User[] = [];
  constructor(private http: HttpClient) { }

  public signup(user: User): Observable<any> {
    return this.http.post('http://localhost:8010/api/home/register', user, {responseType: 'text'});
  }
  public login(email: string, password: string, userLogin: Userlogin): Observable<any> {
    const url = 'http://localhost:8010/api/login/' + email + '/' + password;
    return this.http.post(url, userLogin, {responseType : 'text'});
  }
  public admin(email: string, password: string, userLogin: Userlogin): Observable<any> {
    const url = 'http://localhost:8010/api/admin/' + email + '/' + password;
    return this.http.post(url, userLogin, {responseType : 'text'});
  }
  loadUsers(): Observable<any> {
       return this.http.get('http://localhost:8010/api/getAllUserDetails');
  }
  setUsers(users: User[]): void {
    this.users = users;
  }
  getUsers(): User[] {
    return this.users;
  }
  deleteUserById(userId: number): Observable<any> {
    return this.http.delete('http://localhost:8010/api/deleteUser/' + userId, { responseType: 'text' });
  }
  getUserById(userId: number): Observable<any> {
    return this.http.get('http://localhost:8010/api/getUserById/' + userId);
  }
  updateUser(userId: number, value: any): Observable<any> {
    return this.http.put('http://localhost:8010/api/getUserById/' + userId, value);
  }

  logout(userId: number) {
    return this.http.put('http://localhost:8010/api/logout/' + userId, User );
  }
}
