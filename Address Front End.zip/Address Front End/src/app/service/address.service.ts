import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Address } from '../common/address';
import { throwError, Observable } from 'rxjs';
import { tap, catchError, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AddressService {

  private baseU="http://localhost:8010/api/home/address"
  private baseUrl="http://localhost:8010/api/home/showAll";
  private baseUrl1="http://localhost:8010/api/home/addAddress/7";
  private baseUrl2="http://localhost:8010/api/home/update";
  
  headers = new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json');
  httpOptions = {
    headers: this.headers
  };


  constructor(private http: HttpClient) { }

  private handleError(error: any) {
    console.error(error);                                       //Created a function to handle and log errors, in case
    return throwError(error);
  }



  public getAddresses() {
    return this.http.get<Address[]>(this.baseUrl);
  }


  addAddress (address: Address): Observable<Address> { 
    id1:1;
    address.addressId=null;
    return this.http.post<Address>(this.baseUrl1, address, this.httpOptions).pipe(
    tap(data => console.log(data)),
    catchError(this.handleError)
  );
}
 

getAddress(id: number): Observable<any> {
  return this.http.get(`${this.baseUrl}/${id}`);
}


  createAddress(address: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/${'add'}`, address);
  }

  updateAddress(id: number, value: any): Observable<Object> {
    return this.http.put(`${this.baseU}/${'update'}`, value);
  }

  deleteAddress(id: number): Observable<any> {
    return this.http.delete(`${this.baseU}/${'delete'}/${id}`, { responseType: 'text' });
  }

  getAddressList(): Observable<any> {
    return this.http.get(`${this.baseUrl}/${'show'}`);
  }
}




