import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/common/user';
import { UserService } from 'src/app/service/user.service';
import { Router } from '@angular/router';
import { Userlogin } from 'src/app/common/userlogin';
import { AuthenticateService } from 'src/app/service/authenticate.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent  {

  userLogin: Userlogin = new Userlogin();
  email: String;
  password: String; 
  info: string;
  errorInfo: string;
  constructor(private userService: UserService, private route: Router, private authService: AuthenticateService) { }

  admin() {
    console.log(' admin logging in');
    console.log(this.userLogin.email);
    console.log(this.userLogin.password);
    this.authService.admin(this.userLogin);
    this.userService.admin(this.userLogin.email, this.userLogin.password, this.userLogin).subscribe(data => {
      this.info = data;
      this.route.navigate(['/admin/admincontrol']);
      // alert(this.info);
      },

      error => {
        this.info = undefined;
        this.errorInfo = error.error;
        console.log(this.errorInfo);
        alert(this.errorInfo);
      } );
  }
    onSubmit() {
      this.route.navigate(['/admin/admincontrol']);
    }
}
