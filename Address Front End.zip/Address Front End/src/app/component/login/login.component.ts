import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/common/user';
import { UserService } from 'src/app/service/user.service';
import { Router } from '@angular/router';
import { Userlogin } from 'src/app/common/userlogin';
import { AuthenticateService } from 'src/app/service/authenticate.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  userLogin: Userlogin = new Userlogin();
  email: String;
  password: String; 
  info: string;
  errorInfo: string;
  constructor(private userService: UserService, private route: Router, private authService: AuthenticateService) { }

  login() {
    console.log('User logging in');
    console.log(this.userLogin.email);
    console.log(this.userLogin.password);
    this.authService.login(this.userLogin);
    this.userService.login(this.userLogin.email, this.userLogin.password, this.userLogin).subscribe(data => {
      this.info = data;
      this.route.navigate(['/home']);
      },

      error => {
        this.info = undefined;
        this.errorInfo = error.error;
        console.log(this.errorInfo);
        alert(this.errorInfo);
      } );
  }
  // ngOnInit(): void {
  //   this.route.navigate(['/home']);
  // }
    onSubmit() {
      this.route.navigate(['/home']);
  }
  signup() {
    this.route.navigate(['/signup']);
  }
  login2() {
    this.route.navigate(['/login']);
  }
  home() {
    this.route.navigate(['/home']);
  }
}
