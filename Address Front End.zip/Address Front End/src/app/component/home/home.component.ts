import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticateService } from 'src/app/service/authenticate.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent  {
  constructor(private authService: AuthenticateService, private route: Router) { }
     logout() {
     this.authService.logout();
    this.route.navigateByUrl('/login');
  }
  onSubmit() {
    this.route.navigate(['/login']);
  }
}
