import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './component/login/login.component';
import { SignupComponent } from './component/signup/signup.component';
import { HomeComponent } from './component/home/home.component';
import { AdminComponent } from './component/admin/admin.component';
import { AdmimcontrolComponent } from './component/admincontrol/admincontrol.component';
import { AuthGuardService } from './service/auth-guard.service';
import { AdminGuardService } from './service/admin-guard.service';
import { PagenotfoundComponent } from './component/pagenotfound/pagenotfound.component';
import { AddressService } from './service/address.service';
import { UserService } from './service/user.service';
import { CreateAddressComponent } from './component/create-address/create-address.component';
import { UpdateAddressComponent } from './component/update-address/update-address.component';
import { AddressDetailsComponent } from './component/address-details/address-details.component';
import { AddressListComponent } from './component/address-list/address-list.component';


const routes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'signup', component: SignupComponent},
  {path: 'home', component: HomeComponent, canActivate: [AuthGuardService]},
  {path: 'home/address', component: AddressListComponent},
  {path: 'home/add',component: CreateAddressComponent},
  {path: 'update/:id',component:UpdateAddressComponent},
  {path: 'details/:id',component:AddressDetailsComponent},
  {path: 'admin', component: AdminComponent},
  {path: 'admin/admincontrol', component: AdmimcontrolComponent, canActivate: [AdminGuardService]},
  {path: '', component: LoginComponent},
  //{path: '**', component: PagenotfoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
